# Lately agent

The iMessage side of **Lately**. Users text the Lately number photos, short videos, and notes about their week. This worker receives those messages through [Photon Spectrum](https://photon.codes/spectrum) (`spectrum-ts`, cloud iMessage provider) and replies.

**Milestone 1 (current):** an echo loop that proves the pipeline works end to end.

| Inbound | Reply |
| --- | --- |
| Text | `Lately got: <text>` |
| One photo (image/*, HEIC) | `Got your photo 📸` |
| One video (video/*, .mov, .mp4) | `Got your video 🎬` |
| Several attachments sent together | One summary, e.g. `Got your 3 photos and 1 video 📸🎬` |
| Reactions, read receipts, typing, etc. | Ignored |

- A typing indicator shows while the agent works on a reply.
- Each sender's messages are handled in order through a per-sender queue, so one sender's slow work never blocks anyone else.
- Each inbound message is logged as one line (timestamp, sender, content type). Each attachment's name, mimeType, and size are logged too. Nothing is saved yet.
- An error in one message is logged and never crashes the loop.

Coming next: onboarding, saving media to Supabase, Muse Spark postcard generation, and weekly cron sends. Most of that goes in `src/handler.ts`.

## Layout

```
agent/
  src/
    config.ts   # loads .env, validates required env vars
    index.ts    # starts Spectrum, message loop, per-sender queue, shutdown
    handler.ts  # handleInbound(): flattens content, decides the reply
  .env.example
  package.json
  tsconfig.json
```

The folder is self-contained, with its own dependencies and config, and nothing outside `agent/` is imported.

## Run locally

Requires Node 20+.

```bash
cd agent
npm install
cp .env.example .env      # then fill in PHOTON_PROJECT_ID and PHOTON_PROJECT_SECRET
npm run dev               # tsx watch: restarts on file changes
```

You should see `Lately is listening…`. Text your Photon iMessage number from your phone and you'll get a reply.

If a variable is missing, startup fails with a message like `Missing env var PHOTON_PROJECT_ID`.

Other scripts:

- `npm start`: run once without watching (this is what Railway runs)
- `npm run typecheck`: `tsc --noEmit`

## Deploy to Railway

This is a **background worker**. It has no HTTP server, no port, and no health check. It holds a streaming connection to Spectrum.

1. Create a new service from the GitHub repo.
2. **Settings → Root Directory:** `agent/`
3. **Start command:** `npm start`
4. **Variables:** add `PHOTON_PROJECT_ID` and `PHOTON_PROJECT_SECRET`.
5. **Restart policy:** "On Failure"
6. Don't generate a public domain. Nothing needs one.

If the Spectrum message stream ever ends (for example, a dropped connection), the process logs it and exits with code 1, and Railway restarts it. On SIGTERM (a redeploy), it calls `app.stop()` and exits 0.

`tsx` is a regular dependency (not a devDependency), so it's still installed if Railway prunes dev dependencies.

## Merging into the Next.js repo

1. Copy this whole `agent/` folder into the repo root. Leave out `node_modules` and `.env`; both are gitignored.
2. If the Next.js app is also at the repo root, keep Next's build from typechecking or linting the agent:
   - Root `tsconfig.json`: add `"agent"` to `exclude`:
     ```json
     "exclude": ["node_modules", "agent"]
     ```
   - ESLint: add `agent/**` to the ignore list. Flat config (`eslint.config.mjs`):
     ```js
     { ignores: ["agent/**"] }
     ```
     Legacy `.eslintrc`: add `agent` to `.eslintignore`.
3. Keep installing and running the agent from inside `agent/` (`cd agent && npm install`). Don't add it to npm workspaces.
4. In Railway, the agent is its own service with root directory `agent/`. The web app is a separate service.
