import type { Content, Message, Space, SpectrumInstance } from "spectrum-ts";

export type App = SpectrumInstance;

type Attachment = Extract<Content, { type: "attachment" }>;

export type MediaKind = "photo" | "video";

export interface MediaItem {
  kind: MediaKind;
  name: string;
  mimeType: string;
  attachment: Attachment;
}

/** Everything useful in one inbound message, with groups flattened. */
export interface Inbound {
  texts: string[];
  media: MediaItem[];
}

const PHOTO_EXT = /\.(jpe?g|png|gif|webp|heic|heif)$/i;
const VIDEO_EXT = /\.(mov|mp4|m4v)$/i;

export function classifyAttachment(name: string, mimeType: string): MediaKind | undefined {
  const mime = mimeType.toLowerCase();
  if (mime.startsWith("image/") || PHOTO_EXT.test(name)) return "photo";
  if (mime.startsWith("video/") || mime === "application/quicktime" || VIDEO_EXT.test(name)) {
    return "video";
  }
  return undefined;
}

/** Recursively flattens a message's content into texts and media. */
export function flatten(content: Content, into: Inbound = { texts: [], media: [] }): Inbound {
  switch (content.type) {
    case "text":
      if (content.text.trim()) into.texts.push(content.text);
      break;
    case "attachment": {
      const kind = classifyAttachment(content.name, content.mimeType);
      if (kind) {
        into.media.push({ kind, name: content.name, mimeType: content.mimeType, attachment: content });
      } else {
        console.log(`  skipping unsupported attachment ${content.name} (${content.mimeType})`);
      }
      break;
    }
    case "group":
      for (const item of content.items) flatten(item.content, into);
      break;
    default:
      // Reactions, read receipts, typing, etc.
      break;
  }
  return into;
}

/** Short label for the per-message log line. */
export function describeContent(content: Content): string {
  return content.type === "group" ? `group(${content.items.length})` : content.type;
}

function plural(n: number, word: string): string {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

function mediaReply(media: MediaItem[]): string {
  const photos = media.filter((m) => m.kind === "photo").length;
  const videos = media.length - photos;
  if (media.length === 1) return photos ? "Got your photo 📸" : "Got your video 🎬";

  const parts: string[] = [];
  if (photos) parts.push(plural(photos, "photo"));
  if (videos) parts.push(plural(videos, "video"));
  const emoji = (photos ? "📸" : "") + (videos ? "🎬" : "");
  return `Got your ${parts.join(" and ")} ${emoji}`;
}

async function logMedia(item: MediaItem): Promise<void> {
  // TODO(next milestone): upload `bytes` to Supabase storage instead of just measuring it.
  try {
    const size = item.attachment.size ?? (await item.attachment.read()).byteLength;
    console.log(`  ${item.kind}: ${item.name} (${item.mimeType}, ${size} bytes)`);
  } catch (err) {
    console.error(`  failed to read ${item.name}:`, err);
  }
}

/**
 * Handles one inbound message from one sender. Called serially per sender.
 * Onboarding, saving to Supabase, and Muse Spark calls plug in here.
 */
export async function handleInbound(app: App, space: Space, message: Message): Promise<void> {
  const inbound = flatten(message.content);
  if (inbound.texts.length === 0 && inbound.media.length === 0) return;

  await app.responding(space, async () => {
    for (const item of inbound.media) await logMedia(item);

    const replies: string[] = [];
    if (inbound.texts.length > 0) replies.push(`Lately got: ${inbound.texts.join("\n")}`);
    if (inbound.media.length > 0) replies.push(mediaReply(inbound.media));

    await space.send(replies.join("\n"));
  });
}
